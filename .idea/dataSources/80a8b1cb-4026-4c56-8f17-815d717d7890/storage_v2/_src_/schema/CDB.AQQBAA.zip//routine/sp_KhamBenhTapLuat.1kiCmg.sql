create
    definer = root@`%` procedure sp_KhamBenhTapLuat(IN vung_id int)
BEGIN
  SET @row_number = 0;
  SELECT
    (@row_number := @row_number + 1) AS Num,
    tam2.ICDId,
    i.MaICD,
    i.TenICD,
    tam2.TapLuatId,
    GROUP_CONCAT(tam2.tentcc, IF(tam2.tentckt IS NOT NULL, CONCAT('. Đồng thời có các ', tam2.tentckt), '')) AS KhamBenhTrieuChung
  FROM (SELECT
      tam1.ICDId,
      tam1.TapLuatId,
      GROUP_CONCAT(tam1.tentrieuchungchinh) AS tentcc,
      GROUP_CONCAT(tam1.tentrieuchungkemtheo) AS tentckt
    FROM (SELECT
        i.ICDId,
        tl.TapLuatId,

        (SELECT
            GROUP_CONCAT(LOWER(CONCAT_WS(": ", ltc1.TenLoaiTinhChat, tc1.TenTinhChat)) SEPARATOR '; ') AS Chuoi
          FROM TinhChat tc1
            LEFT JOIN TapLuatTrieuChungTinhChat tltctc1
              ON tc1.TinhChatId = tltctc1.TinhChatId
            LEFT JOIN LoaiTinhChat ltc1
              ON tc1.LoaiTinhChatId = ltc1.LoaiTinhChatId
          WHERE tltc.TapLuatTrieuChungId = tltctc1.TapLuatTrieuChungId
          ORDER BY ltc1.TenLoaiTinhChat) AS tentrieuchungchinh,
        CONCAT('triệu chứng kèm theo như: ', GROUP_CONCAT(CASE WHEN tltc.TrieuChungChinh = 0 THEN LOWER(tc.TenTrieuChung) END SEPARATOR ', '), '.') AS tentrieuchungkemtheo

      FROM TrieuChung tc
        LEFT JOIN TapLuatTrieuChung tltc
          ON tc.TrieuChungId = tltc.TrieuChungId
        LEFT JOIN TapLuat tl
          ON tltc.TapLuatId = tl.TapLuatId
        LEFT JOIN ICDBenh i
          ON i.ICDId = tl.ICDId
        LEFT JOIN NhomICDTheoVung niv
          ON i.NhomId = niv.NhomId
      WHERE niv.VungId = vung_id
      GROUP BY i.ICDId,
               tl.TapLuatId,
               tentrieuchungchinh) tam1
    GROUP BY tam1.ICDId,
             tam1.TapLuatId) tam2
    LEFT JOIN ICDBenh i
      ON i.ICDId = tam2.ICDId
  GROUP BY tam2.ICDId,
           i.MaICD,
           i.TenICD,
           tam2.TapLuatId;
END;

