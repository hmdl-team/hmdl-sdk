create definer = root@`%` trigger before_khambenh_insert
    before insert
    on KhamBenh
    for each row
BEGIN
  SET
  @prefix_SoKhamBenh := 'KB' + RIGHT(YEAR(CURRENT_DATE()), 2) * 10000,
  @suffix_SoKhamBenh := (SELECT
      COUNT(kb.KhamBenhId) + 1
    FROM KhamBenh kb
    WHERE YEAR(kb.NgayTao) = YEAR(CURDATE())),
  @SoKhamBenh = CONCAT('KB', @prefix_SoKhamBenh + @suffix_SoKhamBenh),
  NEW.SoPhieuKham = @SoKhamBenh,
  NEW.NgayTao = CURRENT_TIME,
  NEW.NgayKhamBenh = CURRENT_DATE,
  NEW.NgayCapNhat = CURRENT_TIME;
END;

