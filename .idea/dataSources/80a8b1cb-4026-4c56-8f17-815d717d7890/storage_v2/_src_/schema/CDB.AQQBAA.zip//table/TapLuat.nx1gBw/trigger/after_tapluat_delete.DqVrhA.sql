create definer = root@`%` trigger after_tapluat_delete
    after delete
    on TapLuat
    for each row
BEGIN
  UPDATE ICDBenh i
  SET i.DaTaoTapLuat = 0
  WHERE i.ICDId = OLD.ICDId;
END;

