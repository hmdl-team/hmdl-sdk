create
    definer = root@`%` procedure GetDSVungTheoBoPhan(IN boPhanId int)
BEGIN
  SELECT
    BoPhanId,
    v.VungId,
    v.TenVung
  FROM Vung v
  WHERE v.BoPhanId = boPhanId
  AND v.TamNgung = 0;
END;

