create view temp_result as
select `tl`.`ICDId` AS                                                                          `ICDId`,
       `icdb`.`MaICD` AS                                                                        `MaICD`,
       `bp`.`TenBoPhan` AS                                                                      `TenBoPhan`,
       `v`.`TenVung` AS                                                                         `TenVung`,
       max(if((`tam1`.`TenTrieuChung` = 'Buồn nôn'), `tam1`.`TrangThai`, NULL)) AS              `buonnon`,
       max(if((`tam1`.`TenTrieuChung` = 'Đau'), `tam1`.`TrangThai`, NULL)) AS                   `dau`,
       max(if((`tam1`.`TenTrieuChung` = 'Đầy hơi'), `tam1`.`TrangThai`, NULL)) AS               `dayhoi`,
       max(if((`tam1`.`TenTrieuChung` = 'Nôn'), `tam1`.`TrangThai`, NULL)) AS                   `non`,
       max(if((`tam1`.`TenTrieuChung` = 'Ợ hơi'), `tam1`.`TrangThai`, NULL)) AS                 `ohoi`,
       max(if((`tam1`.`TenTrieuChung` = 'Ớn lạnh'), `tam1`.`TrangThai`, NULL)) AS               `onlanh`,
       max(if((`tam1`.`TenTrieuChung` = 'Sốt'), `tam1`.`TrangThai`, NULL)) AS                   `Sot`,
       max(if((`tam2`.`TenLoaiTinhChat` = 'Diễn biến cơn đau'), `tam2`.`TenTinhChat`, NULL)) AS `dienbiencondau`,
       max(if((`tam2`.`TenLoaiTinhChat` = 'Hướng lan'), `tam2`.`TenTinhChat`, NULL)) AS         `huonglan`,
       max(if((`tam2`.`TenLoaiTinhChat` = 'Kiểu đau'), `tam2`.`TenTinhChat`, NULL)) AS          `kieudau`,
       max(if((`tam2`.`TenLoaiTinhChat` = 'Yếu tố ảnh hưởng đến cơn đau'), `tam2`.`TenTinhChat`,
              NULL)) AS                                                                         `yeutoanhhuongdencondau`
from ((((((`CDB`.`TapLuat` `tl` left join `CDB`.`tam1` on ((`tl`.`TapLuatId` = `tam1`.`TapLuatId`))) left join `CDB`.`tam2` on ((`tam1`.`TapLuatId` = `tam2`.`TapLuatId`))) left join `CDB`.`ICDBenh` `icdb` on ((`tl`.`ICDId` = `icdb`.`ICDId`))) left join `CDB`.`NhomICDTheoVung` `nicdtv` on ((`nicdtv`.`NhomId` = `icdb`.`NhomId`))) left join `CDB`.`Vung` `v` on ((`nicdtv`.`VungId` = `v`.`VungId`)))
         left join `CDB`.`BoPhanCQ` `bp` on ((`v`.`BoPhanId` = `bp`.`BoPhanId`)))
group by `tl`.`ICDId`, `bp`.`TenBoPhan`, `v`.`TenVung`;

