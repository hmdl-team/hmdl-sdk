create view temp001_pretty as
select `temp001`.`TenBoPhan`                            AS `TenBoPhan`,
       `temp001`.`TenVung`                              AS `TenVung`,
       `temp001`.`TenTrieuChung`                        AS `TenTrieuChung`,
       coalesce(`temp001`.`HuongLan`, '')               AS `HuongLan`,
       coalesce(`temp001`.`KieuDau`, '')                AS `KieuDau`,
       coalesce(`temp001`.`YeuToAnhHuongDenConDau`, '') AS `YeuToAnhHuongDenConDau`,
       coalesce(`temp001`.`DienBienConDau`, '')         AS `DienBienConDau`,
       `temp001`.`MaICD`                                AS `MaICD`
from `CDB`.`temp001`;

