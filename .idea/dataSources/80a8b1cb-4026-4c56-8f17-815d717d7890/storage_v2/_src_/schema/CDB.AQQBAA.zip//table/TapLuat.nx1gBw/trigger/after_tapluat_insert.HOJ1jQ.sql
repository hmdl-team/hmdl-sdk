create definer = root@`%` trigger after_tapluat_insert
    after insert
    on TapLuat
    for each row
BEGIN
  UPDATE ICDBenh i
  SET i.DaTaoTapLuat = 1
  WHERE i.ICDId = NEW.ICDId;
END;

