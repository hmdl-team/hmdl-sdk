create
    definer = root@`%` procedure GetTinhChatTheoBoPhan(IN bophan_id int)
BEGIN
  SELECT DISTINCT
    bpc.BoPhanId,
    bpc.TenBoPhan,
    ltc.LoaiTinhChatId,
    ltc.TenLoaiTinhChat
  FROM TapLuatTrieuChungTinhChat tltctc
    LEFT JOIN TapLuatTrieuChung tltc
      ON tltctc.TapLuatTrieuChungId = tltc.TapLuatTrieuChungId
    LEFT JOIN TapLuat tl
      ON tltc.TapLuatId = tl.TapLuatId
    LEFT JOIN ICDBenh i
      ON tl.ICDId = i.ICDId
    LEFT JOIN NhomICDTheoVung niv
      ON i.NhomId = niv.NhomId
    LEFT JOIN Vung v
      ON niv.VungId = v.VungId
    LEFT JOIN BoPhanCQ bpc
      ON niv.BoPhanId = bpc.BoPhanId
    LEFT JOIN TinhChat tc1
      ON tltctc.TinhChatId = tc1.TinhChatId
    LEFT JOIN LoaiTinhChat ltc
      ON tc1.LoaiTinhChatId = ltc.LoaiTinhChatId
  WHERE tltc.TrieuChungChinh = 1
  AND bpc.BoPhanId = bophan_id;
END;

