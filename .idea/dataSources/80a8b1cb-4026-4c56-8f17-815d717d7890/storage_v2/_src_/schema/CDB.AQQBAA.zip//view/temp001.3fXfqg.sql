create view temp001 as
select `bpc`.`TenBoPhan`                                                                                      AS `TenBoPhan`,
       `v`.`TenVung`                                                                                          AS `TenVung`,
       `tc`.`TenTrieuChung`                                                                                   AS `TenTrieuChung`,
       (case
            when (`ltc`.`TenLoaiTinhChat` like 'Hướng lan')
                then `tc1`.`TenTinhChat` end)                                                                 AS `HuongLan`,
       (case
            when (`ltc`.`TenLoaiTinhChat` like 'Kiểu đau')
                then `tc1`.`TenTinhChat` end)                                                                 AS `KieuDau`,
       (case
            when (`ltc`.`TenLoaiTinhChat` like 'Yếu tố ảnh hưởng đến cơn đau')
                then `tc1`.`TenTinhChat` end)                                                                 AS `YeuToAnhHuongDenConDau`,
       (case
            when (`ltc`.`TenLoaiTinhChat` like 'Diễn biến cơn đau')
                then `tc1`.`TenTinhChat` end)                                                                 AS `DienBienConDau`,
       `i`.`MaICD`                                                                                            AS `MaICD`
from (((((((((`CDB`.`TapLuat` `tl` join `CDB`.`TapLuatTrieuChung` `tltc` on ((`tl`.`TapLuatId` = `tltc`.`TapLuatId`))) join `CDB`.`TapLuatTrieuChungTinhChat` `tltctc` on ((`tltc`.`TapLuatTrieuChungId` = `tltctc`.`TapLuatTrieuChungId`))) join `CDB`.`TinhChat` `tc1` on ((`tltctc`.`TinhChatId` = `tc1`.`TinhChatId`))) join `CDB`.`LoaiTinhChat` `ltc` on ((`tc1`.`LoaiTinhChatId` = `ltc`.`LoaiTinhChatId`))) join `CDB`.`TrieuChung` `tc` on ((`tltc`.`TrieuChungId` = `tc`.`TrieuChungId`))) join `CDB`.`ICDBenh` `i` on ((`tl`.`ICDId` = `i`.`ICDId`))) join `CDB`.`NhomICDTheoVung` `niv` on ((`i`.`NhomId` = `niv`.`NhomId`))) join `CDB`.`Vung` `v` on ((`niv`.`VungId` = `v`.`VungId`)))
         join `CDB`.`BoPhanCQ` `bpc` on ((`niv`.`BoPhanId` = `bpc`.`BoPhanId`)))
where (`tltc`.`TrieuChungChinh` = 1);

