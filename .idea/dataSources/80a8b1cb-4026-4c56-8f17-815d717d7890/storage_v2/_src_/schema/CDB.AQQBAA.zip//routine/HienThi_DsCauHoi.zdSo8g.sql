create
    definer = root@`%` procedure HienThi_DsCauHoi()
BEGIN
  SET @row_num = 0;
  SELECT
    (@row_num := @row_num + 1) AS Num,
    ch.CauHoiId,
    ch.TenCauHoi,
    ch.TenKhongDau,
    ch.TamNgung,
    ch.NhomCauHoiId,
    nch.TenNhomCauHoi
  FROM CauHoi ch
    LEFT JOIN NhomCauHoi nch
      ON ch.NhomCauHoiId = nch.NhomCauHoiId;
END;

