create
    definer = root@`%` procedure sp_KhamBenhKetLuan(IN khambenh_id int)
BEGIN
  DECLARE vungks int;
  DECLARE bophanks int;
  SELECT DISTINCT
    kbct.VungId INTO vungks
  FROM KhamBenhChiTiet kbct
  WHERE kbct.KhamBenhId = khambenh_id;

  SELECT DISTINCT
    kbct.BoPhanId INTO bophanks
  FROM KhamBenhChiTiet kbct
  WHERE kbct.KhamBenhId = khambenh_id;

  SELECT
    ICDTV.ICDId,
    ICDTV.MaICD,
    ICDTV.TenICD,
    IF(KLTrieuChungChinh.TyLe IS NULL, 0, KLTrieuChungChinh.TyLe) + IF(KLTrieuChungPhu.SoTrieuChungPhuTrung IS NULL, 0, KLTrieuChungPhu.SoTrieuChungPhuTrung) AS TyLe,
    KLTrieuChungChinh.SoTinhChatTrung,
    KLTrieuChungChinh.TenTinhChatTrung,
    IF(KLTrieuChungPhu.SoTrieuChungPhuTrung IS NULL, 0, KLTrieuChungPhu.SoTrieuChungPhuTrung) AS SoTrieuChungPhuTrung,
    IF(KLTrieuChungPhu.TenTrieuChungPhuTrung IS NULL, '', KLTrieuChungPhu.TenTrieuChungPhuTrung) AS TenTrieuChungPhuTrung
  -- Bước 1: Lấy toàn bộ danh sách các ICD theo vùng
  FROM (SELECT DISTINCT
      i.ICDId,
      i.MaICD,
      i.TenICD
    FROM ICDBenh i
      JOIN NhomICDTheoVung niv
        ON i.NhomId = niv.NhomId
      JOIN TapLuat tl
        ON i.ICDId = tl.ICDId
    WHERE niv.VungId = vungks) ICDTV
    LEFT JOIN (SELECT
        TongHop.ICDId,
        SUM(TongHop.TyLe) AS TyLe,
        COUNT(TongHop.ICDId) AS SoTinhChatTrung,
        GROUP_CONCAT(TongHop.TenTinhChat SEPARATOR '; ') AS TenTinhChatTrung
      -- Bước 2: Join với bảng TongHop (là bảng dữ liệu dựa vào tính chất để lấy lên tỉ lệ so sánh)
      FROM (SELECT
          i.ICDId,
          tc.TenTinhChat,
          tltlss1.TyLe
        FROM TapLuatTrieuChungTinhChat tltctc
          -- Bước 2.1: Lấy ra danh sách ICD đã khai báo tập luật
          JOIN TapLuatTrieuChung tltc
            ON tltctc.TapLuatTrieuChungId = tltc.TapLuatTrieuChungId
          JOIN TapLuat tl
            ON tltc.TapLuatId = tl.TapLuatId
          JOIN ICDBenh i
            ON tl.ICDId = i.ICDId
          -- Bước 2.2: Join với nhóm của vùng đang khảo sát
          JOIN NhomICDTheoVung niv
            ON i.NhomId = niv.NhomId
            AND niv.VungId = vungks
          -- Bước 2.3: Join với bảng tính chất khám bệnh của Bệnh nhân
          JOIN (SELECT
              kbcttc.TinhChatId
            FROM KhamBenhChiTietTinhChat kbcttc
              JOIN KhamBenhChiTiet kbct
                ON kbcttc.KhamBenhChiTietId = kbct.KhamBenhChiTietId
              JOIN KhamBenh kb
                ON kbct.KhamBenhId = kb.KhamBenhId
              JOIN TinhChat tc
                ON kbcttc.TinhChatId = tc.TinhChatId
            WHERE kb.KhamBenhId = khambenh_id
            AND kbct.TrieuChungChinh = 1) kbtc
            ON tltctc.TinhChatId = kbtc.TinhChatId
          JOIN TinhChat tc
            ON kbtc.TinhChatId = tc.TinhChatId
          -- Bước 2.4: Join với bảng tỷ lệ so sánh chất để lấy lên tỷ lệ so sánh
          JOIN (SELECT
              tltlss.LoaiTinhChatId,
              tltlss.TyLe,
              tltlss.`Index`
            FROM TapLuatTyLeSoSanh tltlss
            WHERE tltlss.BoPhanId = bophanks) tltlss1
            ON tc.LoaiTinhChatId = tltlss1.LoaiTinhChatId) AS TongHop
      GROUP BY TongHop.ICDId) AS KLTrieuChungChinh
      ON KLTrieuChungChinh.ICDId = ICDTV.ICDId
    -- Bước 3: Left join với Bảng triệu chứng phụ
    LEFT JOIN (SELECT
        TongHop.ICDId,
        COUNT(TongHop.ICDId) AS SoTrieuChungPhuTrung,
        GROUP_CONCAT(TongHop.TenTrieuChung SEPARATOR '; ') AS TenTrieuChungPhuTrung
      FROM (SELECT
          kbct.TrieuChungId,
          tc.TenTrieuChung,
          tl.ICDId
        FROM KhamBenhChiTiet kbct
          LEFT JOIN KhamBenh kb
            ON kbct.KhamBenhId = kb.KhamBenhId
          LEFT JOIN TapLuatTrieuChung tltc
            ON kbct.TrieuChungId = tltc.TrieuChungId
          LEFT JOIN TapLuat tl
            ON tltc.TapLuatId = tl.TapLuatId
          LEFT JOIN TrieuChung tc
            ON kbct.TrieuChungId = tc.TrieuChungId
          LEFT JOIN ICDBenh i
            ON tl.ICDId = i.ICDId
        WHERE kb.KhamBenhId = khambenh_id
        AND kbct.TrieuChungChinh <> 1) AS TongHop
      GROUP BY TongHop.ICDId) AS KLTrieuChungPhu
      ON ICDTV.ICDId = KLTrieuChungPhu.ICDId;
END;

