create
    definer = root@`%` procedure Ghep_Chuoi_TC(IN TLTC_Id int)
BEGIN
  SELECT
    GROUP_CONCAT(LOWER(CONCAT_WS(": ", ltc.TenLoaiTinhChat, tc1.TenTinhChat)) SEPARATOR '; ') AS Chuoi
  FROM TinhChat tc1
    LEFT JOIN TapLuatTrieuChungTinhChat tltctc
      ON tc1.TinhChatId = tltctc.TinhChatId
    LEFT JOIN LoaiTinhChat ltc
      ON tc1.LoaiTinhChatId = ltc.LoaiTinhChatId
  WHERE tltctc.TapLuatTrieuChungId = TLTC_Id;
END;

