create view tam1 as
select `tltc`.`TapLuatId`   AS `TapLuatId`,
       `tc`.`TrieuChungId`  AS `TrieuChungId`,
       `tc`.`TenTrieuChung` AS `TenTrieuChung`,
       `tc`.`TenKhongDau`   AS `TenKhongDau`,
       'Yes'                AS `TrangThai`
from (`CDB`.`TapLuatTrieuChung` `tltc`
         join `CDB`.`TrieuChung` `tc` on ((`tltc`.`TrieuChungId` = `tc`.`TrieuChungId`)));

