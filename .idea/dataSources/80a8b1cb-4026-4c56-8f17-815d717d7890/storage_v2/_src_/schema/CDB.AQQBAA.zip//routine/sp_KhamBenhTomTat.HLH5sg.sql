create
    definer = root@`%` procedure sp_KhamBenhTomTat(IN khambenh_id int)
BEGIN
  SET @row_num = 0;
  SELECT
    (@row_num := @row_num + 1) AS Num,
    tam.*
  FROM (SELECT
      (SELECT
          ch.TenCauHoi
        FROM CauHoi ch
        WHERE ch.NhomCauHoiId = nch.NhomCauHoiId
        ORDER BY RAND()
        LIMIT 1) AS TenCauHoi,
      tc.TenTinhChat
    FROM KhamBenh kb
      JOIN KhamBenhChiTiet kbct
        ON kb.KhamBenhId = kbct.KhamBenhId
      JOIN KhamBenhChiTietTinhChat kbcttc
        ON kbct.KhamBenhChiTietId = kbcttc.KhamBenhChiTietId
      JOIN TinhChat tc
        ON kbcttc.TinhChatId = tc.TinhChatId
      JOIN LoaiTinhChat ltc
        ON tc.LoaiTinhChatId = ltc.LoaiTinhChatId
      JOIN TrieuChung tc1
        ON kbct.TrieuChungId = tc1.TrieuChungId
      JOIN NhomCauHoi nch
        ON ltc.NhomCauHoiId = nch.NhomCauHoiId
    WHERE kb.KhamBenhId = khambenh_id

    UNION ALL

    SELECT
      (SELECT
          ch.TenCauHoi
        FROM CauHoi ch
        WHERE ch.NhomCauHoiId = 14
        ORDER BY RAND()
        LIMIT 1) AS TenCauHoi,
      GROUP_CONCAT(tc.TenTrieuChung SEPARATOR "; ")
    FROM KhamBenh kb
      JOIN KhamBenhChiTiet kbct
        ON kb.KhamBenhId = kbct.KhamBenhId
      JOIN TrieuChung tc
        ON kbct.TrieuChungId = tc.TrieuChungId
    WHERE kb.KhamBenhId = khambenh_id
    AND kbct.TrieuChungChinh = 0) tam;
END;

