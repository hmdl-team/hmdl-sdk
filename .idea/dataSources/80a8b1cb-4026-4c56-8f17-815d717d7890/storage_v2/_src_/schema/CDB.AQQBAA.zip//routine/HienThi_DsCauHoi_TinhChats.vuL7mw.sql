create
    definer = root@`%` procedure HienThi_DsCauHoi_TinhChats(IN loaitinhchatid int, IN vungid int)
BEGIN
  SET @row_num = 0;
  SELECT
    (@row_num := @row_num + 1) AS Num,
    tam.*
  FROM (SELECT DISTINCT
      tc.TinhChatId,
      tc.TenTinhChat,
      tc.LoaiTinhChatId
    FROM TinhChat tc
      JOIN TapLuatTrieuChungTinhChat tltctc
        ON tc.TinhChatId = tltctc.TinhChatId
      JOIN TapLuatTrieuChung tltc
        ON tltctc.TapLuatTrieuChungId = tltc.TapLuatTrieuChungId
      JOIN TapLuat tl
        ON tltc.TapLuatId = tl.TapLuatId
      JOIN ICDBenh i
        ON tl.ICDId = i.ICDId
      JOIN NhomICDTheoVung niv
        ON i.NhomId = niv.NhomId
    WHERE tc.LoaiTinhChatId = loaitinhchatid
    AND tltc.TrieuChungChinh = 1
    AND niv.VungId = vungid) AS tam;
END;

