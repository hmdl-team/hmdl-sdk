create
    definer = root@`%` procedure HienThi_DsCauHoi_TrieuChungChinh(IN vungid int)
BEGIN
  SET @row_num = 0;
  SELECT
    (@row_num := @row_num + 1) AS Num,
    (SELECT
        ch.TenCauHoi
      FROM CauHoi ch
      WHERE ch.NhomCauHoiId = tam.NhomCauHoiId
      ORDER BY RAND()
      LIMIT 1) AS TenCauHoi,
    1 AS Type,
    tam.*
  FROM (SELECT DISTINCT
      ltc.LoaiTinhChatId,
      ltc.TenLoaiTinhChat,
      ltc.NhomCauHoiId
    --     FROM LoaiTinhChat ltc
    --       LEFT JOIN TinhChat tc
    --         ON ltc.LoaiTinhChatId = tc.LoaiTinhChatId
    --       LEFT JOIN TapLuatTrieuChungTinhChat tltctc
    --         ON tc.TinhChatId = tltctc.TinhChatId
    --       LEFT JOIN TapLuatTrieuChung tltc
    --         ON tltctc.TapLuatTrieuChungId = tltc.TapLuatTrieuChungId
    --       LEFT JOIN TapLuat tl
    --         ON tltc.TapLuatId = tl.TapLuatId
    --       LEFT JOIN ICDBenh i
    --         ON tl.ICDId = i.ICDId
    --       LEFT JOIN NhomICDTheoVung niv
    --         ON i.NhomId = niv.NhomId
    FROM NhomICDTheoVung niv
      LEFT JOIN ICDBenh i
        ON niv.NhomId = i.NhomId
      LEFT JOIN TapLuat tl
        ON i.ICDId = tl.ICDId
      LEFT JOIN TapLuatTrieuChung tltc
        ON tl.TapLuatId = tltc.TapLuatId
      LEFT JOIN TapLuatTrieuChungTinhChat tltctc
        ON tltc.TapLuatTrieuChungId = tltctc.TapLuatTrieuChungId
      LEFT JOIN TinhChat tc
        ON tc.TinhChatId = tltctc.TinhChatId
      LEFT JOIN LoaiTinhChat ltc
        ON ltc.LoaiTinhChatId = tc.LoaiTinhChatId
    WHERE niv.VungId = vungid
    AND tltc.TrieuChungChinh = 1) AS tam;
END;

