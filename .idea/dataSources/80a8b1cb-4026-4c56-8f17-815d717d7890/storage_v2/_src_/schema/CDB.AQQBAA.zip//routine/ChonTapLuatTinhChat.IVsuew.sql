create
    definer = root@`%` procedure ChonTapLuatTinhChat(IN tapLuatTrieuChungId int)
BEGIN
  SELECT
    tltctc.TapLuatTrieuChungId,
    ltc.TenLoaiTinhChat,
    tc.TenTinhChat,
    tltctc.TinhChatChinh
  FROM TapLuatTrieuChungTinhChat tltctc
    LEFT JOIN TinhChat tc
      ON tc.TinhChatId = tltctc.TinhChatId
    LEFT JOIN LoaiTinhChat ltc
      ON tc.LoaiTinhChatId = ltc.LoaiTinhChatId
  WHERE tltctc.TapLuatTrieuChungId = tapLuatTrieuChungId;
END;

