create
    definer = root@`%` procedure GetDsTrieuChungPhu(IN vungid int)
BEGIN
  SET @row_number = 0;
  SELECT
    (@row_number := @row_number + 1) AS Num,
    Tam1.*
  FROM (SELECT DISTINCT
      tc.TrieuChungId,
      tc.TenTrieuChung
    --   FROM TrieuChung tc
    --     LEFT JOIN TapLuatTrieuChung tltc
    --       ON tc.TrieuChungId = tltc.TrieuChungId
    --     LEFT JOIN TapLuat tl
    --       ON tltc.TapLuatId = tl.TapLuatId
    --     LEFT JOIN ICDBenh i
    --       ON i.ICDId = tl.ICDId
    --     LEFT JOIN NhomICDTheoVung niv
    --       ON i.NhomId = niv.NhomId
    FROM NhomICDTheoVung niv
      LEFT JOIN ICDBenh i
        ON niv.NhomId = i.NhomId
      LEFT JOIN TapLuat tl
        ON i.ICDId = tl.ICDId
      LEFT JOIN TapLuatTrieuChung tltc
        ON tl.TapLuatId = tltc.TapLuatId
      LEFT JOIN TrieuChung tc
        ON tltc.TrieuChungId = tc.TrieuChungId
    WHERE niv.VungId = vungid
    AND tltc.TrieuChungChinh = 0) Tam1;
END;

