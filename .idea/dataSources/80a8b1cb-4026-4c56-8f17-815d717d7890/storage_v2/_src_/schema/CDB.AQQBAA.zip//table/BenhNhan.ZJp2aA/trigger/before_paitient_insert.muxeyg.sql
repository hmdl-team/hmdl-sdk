create definer = root@`%` trigger before_paitient_insert
    before insert
    on BenhNhan
    for each row
    SET
  @prefix_MaYTe := RIGHT(YEAR(CURRENT_DATE()), 2) * 10000,
  @suffix_MaYTe := (SELECT
      COUNT(bn.MaYTe) + 1
    FROM BenhNhan bn
    WHERE YEAR(bn.NgayTao) = YEAR(CURDATE())),
  @MaYTe = @prefix_MaYTe + @suffix_MaYTe,
  NEW.MaYTe = @MaYTe,
  NEW.NgayTao = CURRENT_TIME,
  NEW.NgayCapNhat = CURRENT_TIME;

