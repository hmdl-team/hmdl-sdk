create
    definer = root@`%` procedure GetDSTrieuChungByNhomICD(IN nhomId int)
BEGIN
  SELECT
    i.ICDId,
    tl.TapLuatId,
    tc.TrieuChungId,
    tc.MaTrieuChung,
    tc.TenTrieuChung
  FROM TrieuChung tc
    LEFT JOIN TapLuatTrieuChung tltc
      ON tc.TrieuChungId = tltc.TrieuChungId
    LEFT JOIN TapLuat tl
      ON tltc.TapLuatId = tl.TapLuatId
    LEFT JOIN ICDBenh i
      ON i.ICDId = tl.ICDId
  WHERE i.NhomId = nhomId;
END;

