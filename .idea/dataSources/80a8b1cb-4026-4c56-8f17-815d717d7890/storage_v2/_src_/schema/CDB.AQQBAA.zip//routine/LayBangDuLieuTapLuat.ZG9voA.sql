create
    definer = root@`%` procedure LayBangDuLieuTapLuat()
BEGIN

  DROP VIEW IF EXISTS tam1;
  DROP VIEW IF EXISTS tam2;
  CREATE VIEW tam1
  AS
  SELECT
    tltc.TapLuatId,
    tc.TrieuChungId,
    tc.TenTrieuChung,
    tc.TenKhongDau,
    'Yes' AS TrangThai
  FROM TapLuatTrieuChung tltc
    JOIN TrieuChung tc
      ON tltc.TrieuChungId = tc.TrieuChungId;


  SET @sql = NULL;
  SELECT
    GROUP_CONCAT(DISTINCT
    CONCAT(
    'MAX(IF(tam1.TenTrieuChung = ''',
    tam1.TenTrieuChung,
    ''', tam1.TrangThai, NULL)) AS ',
    REPLACE(tam1.TenKhongDau, ' ', '')  --  REPLACE(`col_name`, ' ', '')
    )
    ) INTO @sql
  FROM tam1;

  CREATE VIEW tam2
  AS
  SELECT
    tltc.TapLuatId,
    ltc.TenLoaiTinhChat,
    tc.TenTinhChat,
    ltc.TenKhongDau
  FROM TapLuatTrieuChungTinhChat tltctc
    JOIN TinhChat tc
      ON tltctc.TinhChatId = tc.TinhChatId
    JOIN TapLuatTrieuChung tltc
      ON tltctc.TapLuatTrieuChungId = tltc.TapLuatTrieuChungId
    JOIN LoaiTinhChat ltc
      ON tc.LoaiTinhChatId = ltc.LoaiTinhChatId;

  SET @sql1 = NULL;
  SELECT
    GROUP_CONCAT(DISTINCT
    CONCAT(
    'MAX(IF(tam2.TenLoaiTinhChat = ''',
    tam2.TenLoaiTinhChat,
    ''', tam2.TenTinhChat, NULL)) AS ',
    REPLACE(tam2.TenKhongDau, ' ', '')  --  REPLACE(`col_name`, ' ', '')
    )
    ) INTO @sql1
  FROM tam2;


  SET @sql2 = CONCAT('SELECT 
                     tl.ICDId
                    , icdb.MaICD
                    , bp.TenBoPhan
                    , v.TenVung
                    , ', @sql, ' ,', @sql1, ' 
                   FROM TapLuat tl
                   LEFT JOIN tam1
                    ON tl.TapLuatId = tam1.TapLuatId
                   LEFT JOIN tam2
                    ON tam1.TapLuatId = tam2.TapLuatId
                   LEFT JOIN ICDBenh icdb
                    ON tl.ICDId = icdb.ICDId
                   LEFT JOIN NhomICDTheoVung nicdtv
                    ON nicdtv.NhomId = icdb.NhomId
                    LEFT JOIN Vung v
                    ON nicdtv.VungId = v.VungId
                    LEFT JOIN BoPhanCQ bp
                    ON v.BoPhanId = bp.BoPhanId
                   GROUP BY tl.ICDId,bp.TenBoPhan,v.TenVung');

  PREPARE stmt FROM @sql2;
  EXECUTE stmt;
END;

