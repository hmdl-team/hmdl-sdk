create
    definer = root@`%` procedure KhamBenhTapLuat_01(IN vung_id int)
BEGIN
  SET @row_number = 0;
  SELECT DISTINCT
    ltc.LoaiTinhChatId,
    ltc.TenLoaiTinhChat,
    tc.TinhChatId,
    tc.TenTinhChat,
    tltc.TrieuChungChinh
  FROM TinhChat tc
    LEFT JOIN TapLuatTrieuChungTinhChat tltctc
      ON tc.TinhChatId = tltctc.TinhChatId
    LEFT JOIN LoaiTinhChat ltc
      ON tc.LoaiTinhChatId = ltc.LoaiTinhChatId
    LEFT JOIN TapLuatTrieuChung tltc
      ON tltctc.TapLuatTrieuChungId = tltc.TapLuatTrieuChungId
    LEFT JOIN TrieuChung tc1
      ON tltc.TrieuChungId = tc1.TrieuChungId
    LEFT JOIN TapLuat tl
      ON tltc.TapLuatId = tl.TapLuatId
    LEFT JOIN ICDBenh i
      ON tl.ICDId = i.ICDId
    LEFT JOIN NhomICDTheoVung niv
      ON i.NhomId = niv.NhomId
  WHERE niv.VungId = vung_id
  AND tltc.TrieuChungChinh IS TRUE;
END;

