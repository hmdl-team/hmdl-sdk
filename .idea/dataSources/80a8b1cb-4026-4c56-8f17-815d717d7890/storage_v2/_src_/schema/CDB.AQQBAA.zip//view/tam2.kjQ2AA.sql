create view tam2 as
select `tltc`.`TapLuatId`      AS `TapLuatId`,
       `ltc`.`TenLoaiTinhChat` AS `TenLoaiTinhChat`,
       `tc`.`TenTinhChat`      AS `TenTinhChat`,
       `ltc`.`TenKhongDau`     AS `TenKhongDau`
from (((`CDB`.`TapLuatTrieuChungTinhChat` `tltctc` join `CDB`.`TinhChat` `tc` on ((`tltctc`.`TinhChatId` = `tc`.`TinhChatId`))) join `CDB`.`TapLuatTrieuChung` `tltc` on ((`tltctc`.`TapLuatTrieuChungId` = `tltc`.`TapLuatTrieuChungId`)))
         join `CDB`.`LoaiTinhChat` `ltc` on ((`tc`.`LoaiTinhChatId` = `ltc`.`LoaiTinhChatId`)));

